package com.example.redthread.ui.screen

enum class MetodoPago { DEBITO, CREDITO }

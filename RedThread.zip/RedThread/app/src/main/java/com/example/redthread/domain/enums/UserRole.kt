package com.example.redthread.domain.enums

enum class UserRole {
    USUARIO,
    ADMINISTRADOR,
    DESPACHADOR
}
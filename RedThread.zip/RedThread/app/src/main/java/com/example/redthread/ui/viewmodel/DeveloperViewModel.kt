package com.example.redthread.ui.viewmodel

import androidx.lifecycle.ViewModel

class DeveloperViewModel : ViewModel()
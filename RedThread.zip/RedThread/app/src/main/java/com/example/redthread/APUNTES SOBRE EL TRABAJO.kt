package com.example.redthread

/*
* Esto es para los apuntes para el trabajo
* Se realizo las importaciones necesarias basicas - Si es que hacen falta se agregan junto con un comentario
* Se realizaron todas las carpetas junto con sus archivos basicos, si es que llega a hace necesario agregar y explicar con comentarios del por que se agrego
*
* */

/* a tomar en cuenta
*Dejar comentario en casi todo el codigo ya que so facilitaria la vista
*
* Ser ordenado con el codigo
*
* El NavGraph se realiza despues de haber terminado los screen
* depende de las pantallas ya creada de los screen que en cual actualmente no se ha realizado ninguna
* */


/* Orden ("recomendado por chatgpt")
*   1). Screen
*   2). NavGraph
*   3). Componentes (AppTopBar-AppDrawer)
*   4). ViewModel
*   5). ui.theme
*   6). Conexion final (MainACtivity llama a AppNavGraph con un NavController) como esta realizado con el trabajo del profe
* */